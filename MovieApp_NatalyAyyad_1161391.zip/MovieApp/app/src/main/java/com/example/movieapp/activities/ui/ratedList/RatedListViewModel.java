package com.example.movieapp.activities.ui.ratedList;

import androidx.lifecycle.ViewModel;

public class RatedListViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}