package com.example.movieapp.activities.ui.movieList;

import androidx.lifecycle.ViewModel;

public class MovieListViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}