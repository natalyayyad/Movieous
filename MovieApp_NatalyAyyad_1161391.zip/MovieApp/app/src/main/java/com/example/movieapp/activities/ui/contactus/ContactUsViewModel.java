package com.example.movieapp.activities.ui.contactus;

import androidx.lifecycle.ViewModel;

public class ContactUsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}