package com.example.movieapp.activities.ui.watchList;

import androidx.lifecycle.ViewModel;

public class WatchListViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}